-- Select integer number
SELECT 123 FROM DUAL