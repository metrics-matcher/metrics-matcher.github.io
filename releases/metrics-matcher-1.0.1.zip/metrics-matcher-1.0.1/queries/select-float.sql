-- Select float number
SELECT 123.456 FROM DUAL