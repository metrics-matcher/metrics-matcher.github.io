-- Nthing to select
SELECT 1 FROM DUAL WHERE 1==2