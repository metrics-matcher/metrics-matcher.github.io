-- Select text + ${concatString}
SELECT 'ABC-${concatString}' FROM DUAL