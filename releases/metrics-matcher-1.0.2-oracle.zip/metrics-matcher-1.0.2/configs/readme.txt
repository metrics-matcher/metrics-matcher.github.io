Data sources configuration "datasources.json"
and metric profiles "metrics-profiles.json" should be placed here