-- This query returns nothing
SELECT 1 FROM DUAL WHERE 1=2