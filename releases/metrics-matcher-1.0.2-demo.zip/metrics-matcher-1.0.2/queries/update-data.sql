-- Try to modify database
INSERT INTO DUAL VALUES ('X')