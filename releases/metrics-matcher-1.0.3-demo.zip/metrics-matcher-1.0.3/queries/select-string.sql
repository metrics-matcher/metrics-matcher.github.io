-- Select string
SELECT 'Abc123' FROM DUAL