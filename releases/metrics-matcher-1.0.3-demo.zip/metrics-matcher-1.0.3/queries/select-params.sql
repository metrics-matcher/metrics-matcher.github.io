-- Select text + ${myParam}
SELECT 'ABC-${myParam}' FROM DUAL