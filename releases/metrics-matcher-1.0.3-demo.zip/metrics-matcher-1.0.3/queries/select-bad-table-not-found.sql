-- Select from a nonexistent table
SELECT XXX FROM YYY